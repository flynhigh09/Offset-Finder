﻿using System;
using System.Windows.Forms;
using System.Text;
using System.Linq;
using System.Globalization;
using System.Drawing;
using System.Reflection;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Offset_Finder.Properties;

namespace Offset_Finder
{
    #region PS3 funtions
    public class Cex
    {
        public class DEXMemory
        {
            public static byte[] BIND = new byte[4];
            public static int target = 0xFF;
            public static bool AssemblyLoaded = true;
            public static PS3TMAPI.ResetParameter resetParameter;
            public static PS3TMAPI.ConnectStatus connectStatus;
            static PS3TMAPI.SNRESULT Isok;

            public static string usage;
            public static uint[] ProcessIDs;
            public static uint processID;
            public static string Status;                         
            private static bool connection = false;

            public static int Init()
            {
                processID = DEXMemory.GetProcessID();
                return 0;
            }
            public enum ResetTarget
            {
                Hard,
                Quick,
                ResetEx,
                Soft
            }
            public static uint GetProcessID()
            {
                uint[] numArray;
                var tt = PS3TMAPI.GetProcessList(0, out numArray);
                Isok = PS3TMAPI.GetProcessList(0, out numArray);              
                return numArray[0];
            }
            public static void InitConnection()
            {
                if (!connection)
                {
                    ConnectAttach();
                    connection = true;
                }
                else if (connection)
                {
                    if (MessageBox.Show("PS3 Already Connected and Attached!\nDo you want to Reconnect?", "Reconnect?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                       return;
                   ConnectAttach();
                }
                else
                { 
                    MessageBox.Show("PS3 Connection or Process Attach Failed!", "PS3 Error",  MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    connection = false;
                }
            }
            public static void ConnectAttach()
            {
                PS3TMAPI.InitTargetComms();
                PS3TMAPI.Connect(0, null);

                PS3TMAPI.GetProcessList(0, out ProcessIDs);
                ulong uProcess = ProcessIDs[0];
                processID = Convert.ToUInt32(uProcess);
                PS3TMAPI.ProcessAttach(0, PS3TMAPI.UnitType.PPU, processID);
                PS3TMAPI.ProcessContinue(0, processID);
                DEXMemory.Init();
            }
            public static bool ConnectedAttached()
            {
                try
                {
                    PS3Lib.NET.PS3TMAPI.InitTargetComms();
                    PS3Lib.NET.PS3TMAPI.Connect(0, null);

                    /*run twice to make sure it retrieves it*/
                    PS3Lib.NET.PS3TMAPI.GetProcessList(0, out ProcessIDs);
                    ulong uProcess = ProcessIDs[0];
                    processID = Convert.ToUInt32(uProcess);
                    PS3Lib.NET.PS3TMAPI.ProcessAttach(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, processID);
                    PS3Lib.NET.PS3TMAPI.ProcessContinue(0, processID);
                    DEXMemory.Init();
                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error", ex.Message);
                    return false;
                }
            }
            public static void Attach()
            {
                PS3TMAPI.GetProcessList(0, out ProcessIDs);
                ulong uProcess = ProcessIDs[0];
                processID = Convert.ToUInt32(uProcess);
                PS3TMAPI.ProcessAttach(0, PS3TMAPI.UnitType.PPU, processID);
                PS3TMAPI.ProcessContinue(0, processID);
            }
            public static void DisconnectTarget()
            {
                PS3TMAPI.Disconnect(target);
            }
            public void ResetToXMB(ResetTarget flag)
            {
                if (flag == ResetTarget.Hard)
                    resetParameter = PS3TMAPI.ResetParameter.Hard;
                else if (flag == ResetTarget.Quick)
                    resetParameter = PS3TMAPI.ResetParameter.Quick;
                else if (flag == ResetTarget.ResetEx)
                    resetParameter = PS3TMAPI.ResetParameter.ResetEx;
                else if (flag == ResetTarget.Soft)
                    resetParameter = PS3TMAPI.ResetParameter.Soft;
                PS3TMAPI.Reset(target, resetParameter);
            }
            /// <summary>Power on selected target.</summary>
            public void PowerOn(int numTarget = 0)
            {
                if (target != 0xFF)
                    numTarget = target;
                PS3TMAPI.PowerOn(numTarget);
            }
            /// <summary>Power off selected target.</summary>
            public void PowerOff(bool Force)
            {
                PS3TMAPI.PowerOff(target, Force);
            }
            public static void Pause()
            {
                PS3TMAPI.GetProcessList(0, out ProcessIDs);
                ulong uProcess = ProcessIDs[0];
                processID = Convert.ToUInt32(uProcess);
                PS3TMAPI.ProcessAttach(0, PS3TMAPI.UnitType.PPU, processID);
            }
            public static void Continue()
            {
                PS3TMAPI.GetProcessList(0, out ProcessIDs);
                ulong uProcess = ProcessIDs[0];
                processID = Convert.ToUInt32(uProcess);
                PS3TMAPI.ProcessAttach(0, PS3TMAPI.UnitType.PPU, processID);
                PS3TMAPI.ProcessContinue(0, processID);
            }
            public static string GetIP()
            {
                PS3TMAPI.TCPIPConnectProperties ip = new PS3TMAPI.TCPIPConnectProperties();
                PS3TMAPI.GetConnectionInfo(0, out ip);
                return ip.IPAddress;
            }
            public static string GetStatus()
            {
                PS3TMAPI.ConnectStatus state = new PS3TMAPI.ConnectStatus();
                string use = "";
                PS3TMAPI.GetConnectStatus(0, out state, out use);
                return state.ToString();
            }
            public static string GetGame()
            {
                PS3TMAPI.ProcessInfo infos = new PS3TMAPI.ProcessInfo();
                PS3TMAPI.GetProcessInfo(0, processID, out infos);
                string[] str = infos.Hdr.ELFPath.Split('/');
                string ID = str[3];
                try
                {
                    System.Net.WebClient seeker = new System.Net.WebClient();
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                    string content = seeker.DownloadString("https://a0.ww.np.dl.playstation.net/tpl/np/" + ID + "/" + ID + "-ver.xml").Replace("<TITLE>", ";");
                    string name = content.Split(';')[1].Replace("</TITLE>", ";");
                    return name.Split(';')[0];
                }
                catch
                {
                    return ID;
                }
            }
            public static void SetMemory(uint Address, byte[] Bytes, uint thread = 0)
            {
                PS3Lib.NET.PS3TMAPI.InitTargetComms();
                PS3Lib.NET.PS3TMAPI.ProcessSetMemory(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, processID, thread, Address, Bytes);
            }
            public static void GetMemz(uint Address, byte[] Bytes)
            {
                PS3Lib.NET.PS3TMAPI.InitTargetComms();
                PS3TMAPI.ProcessGetMemory(0, PS3TMAPI.UnitType.PPU, processID, 0L, (ulong)Address, ref Bytes);
            }
            public static byte[] GetMemory(uint Address, int length, uint thread = 0)
            {
                PS3Lib.NET.PS3TMAPI.InitTargetComms();
                byte[] mem = new byte[length];
                PS3Lib.NET.PS3TMAPI.ProcessGetMemory(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, processID, thread, Address, ref mem);
                return mem;
            }
            public static byte[] GetMem(uint Address, int length)
            {
                PS3Lib.NET.PS3TMAPI.InitTargetComms();
                byte[] memout = new byte[length];
                PS3Lib.NET.PS3TMAPI.ProcessGetMemory(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, processID, 0L, (ulong)Address, ref memout);
                return memout;
            }
            public static void SetMemoryI(uint Address, ulong value)
            {
                byte[] Bytes = BitConverter.GetBytes(value);
                Array.Reverse(Bytes);
                PS3TMAPI.ProcessSetMemory(target, PS3TMAPI.UnitType.PPU, processID, 0, Address, Bytes);
            }
            public static byte[] SetMemory(uint address, byte[] memory)
            {
                PS3TMAPI.ProcessSetMemory(0, PS3TMAPI.UnitType.PPU, processID, 0UL, address, memory);
                return memory;
            }
            public static byte[] GetMemory(uint address, byte[] length)
            {
                byte[] numArray = length;
                PS3TMAPI.ProcessGetMemory(0, PS3TMAPI.UnitType.PPU, processID, 0UL, (ulong)address, ref numArray);
                return numArray;
            }
            public static byte[] GetMemoryI(uint address, int length)
            {
                byte[] buffer = new byte[length];
                GetMemory(address, buffer);
                return buffer;
            }
            public static byte[] GetMemoryInt(uint address, int length)
            {
                byte[] numArray = new byte[length];
                PS3TMAPI.ProcessGetMemory(0, PS3TMAPI.UnitType.PPU, processID, 0UL, (ulong)address, ref numArray);
                return numArray;
            }
            private static byte[] myBuffer = new byte[0x20];
            public static void GetMemoryB(uint Address, byte[] Bytes)
            {
                GetMemory(Address, Bytes);
            }
            public static short ReadShort(uint address, bool dvar = false)
            {
                byte[] buff = GetMemory(address, 2, 0);
                if (!dvar) { Array.Reverse(buff); }
                short val = BitConverter.ToInt16(buff, 0);
                return val;
            }
            public static byte ReadByte(uint address)
            {
                byte[] buff = GetMemory(address, 1, 0);
                return buff[0];
            }
            static byte readByte(uint Address)
            {
                return GetMem(Address, 1)[0];
            }
            public static void ReadBytes(uint address, byte[] mem)
            {
                int memory = BitConverter.ToInt32(mem, 0);
                GetMemory(address, memory);
            }
            public static byte[] ReadintByte(uint address, int mem)
            {
                return GetMem(address, mem);
            }
            public static byte[] ReadInt(uint address, int mem)
            {
                GetMemory(address, mem);
                byte[] mem2 = BitConverter.GetBytes(mem);
                return mem2;
            }
            public static int readInts(uint Address, int mem)
            {
                Byte[] read = GetMemory(Address, mem);
                Array.Reverse(read);
                return BitConverter.ToInt32(read, 0);
            }
            public static int readInt(uint Address)
            {
                Byte[] read = GetMem(Address, 4);
                Array.Reverse(read);
                return BitConverter.ToInt32(read, 0);
            }
            public static uint ReadUInt(uint address)
            {
                byte[] buff = new byte[4]; //declaring buff as byte, and byte buff = 4 bytes long [4]
                GetMemoryB(address, buff); // Ps3.Getmemory(youraddress, buff) which buff = 4 bytes long
                Array.Reverse(buff); // reverses the 4 bytes from array, so
                uint val = BitConverter.ToUInt32(buff, 0); //Converts buff from byte to Uint32
                return val; //val = your output 
            }
            public static string Hex2Ascii(string FlyString)
            {
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i <= (FlyString.Length - 2); i += 2)
                {
                    builder.Append(Convert.ToString(Convert.ToChar(int.Parse(FlyString.Substring(i, 2), NumberStyles.HexNumber))));
                }
                return builder.ToString();
            }
            public static string ReplaceString(byte[] bytes)
            {
                string PSNString = BitConverter.ToString(bytes);
                PSNString = PSNString.Replace("00", string.Empty);
                PSNString = PSNString.Replace("-", string.Empty);
                for (int i = 0; i < 10; i++)
                    PSNString = PSNString.Replace("^" + i.ToString(), string.Empty);
                return PSNString;
            }
            public static void WriteFloat(uint offset, float input)
            {
                BitConverter.GetBytes(input).CopyTo(myBuffer, 0);
                Array.Reverse(myBuffer, 0, 4);
                SetMemory(offset, myBuffer);
            }
            public static float ReadFloat(uint offset)
            {
                GetMemory(offset, myBuffer);
                Array.Reverse(myBuffer, 0, 4);
                return BitConverter.ToSingle(myBuffer, 0);
            }
            public static uint ReadUIntB(uint address, byte[] length)
            {
                byte[] buff = length; //new byte[4]; //declaring buff as byte, and byte buff = 4 bytes long [4]
                GetMemory(address, buff); // Ps3.Getmemory(youraddress, buff) which buff = 4 bytes long
                Array.Reverse(buff); // reverses the 4 bytes from array, so
                uint val = BitConverter.ToUInt32(buff, 0); //Converts buff from byte to Uint32
                return val; //val = your output 
            }
            public static string ReadString(uint address)
            {
                int length = 40;
                int message = 0;
                string source = "";
                do
                {
                    byte[] memory = GetMemoryI(address + ((uint) message), length);
                    source = source + Encoding.UTF8.GetString(memory);
                    message += length;
                } while (!source.Contains<char>('\0'));
                int index = source.IndexOf('\0');
                string str2 = source.Substring(0, index);
                source = string.Empty;
                return str2;
            }
            public static void Or_Int32(uint address, int input)
            {
                int num = ReadInt32(address) | input;
                WriteInt32(address, num);
            }
            public static bool ReadBool(uint address)
            {
                return (GetMemoryInt(address, 1)[0] != 0);
            }
            public static byte ReadByteB(uint address)
            {
                byte[] buff = GetMemoryInt(address, 1);
                return buff[0];
            }
            public static byte[] ReadBytes(uint address, int length)
            {
                return GetMemoryInt(address, length);
            }
            public static double ReadDouble(uint address)
            {
                byte[] memory = GetMemoryInt(address, 8);
                Array.Reverse(memory, 0, 8);
                return BitConverter.ToDouble(memory, 0);
            }
            public static double[] ReadDouble(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*8);
                ReverseBytes(memory);
                double[] numArray = new double[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToSingle(memory, ((length - 1) - i)*8);
                }
                return numArray;
            }
            public static short ReadInt16(uint address)
            {
                byte[] memory = GetMemoryInt(address, 2);
                Array.Reverse(memory, 0, 2);
                return BitConverter.ToInt16(memory, 0);
            }
            public static short[] ReadInt16(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*2);
                ReverseBytes(memory);
                short[] numArray = new short[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToInt16(memory, ((length - 1) - i)*2);
                }
                return numArray;
            }
            public static int ReadInt32(uint address)
            {
                byte[] memory = GetMemoryInt(address, 4);
                Array.Reverse(memory, 0, 4);
                return BitConverter.ToInt32(memory, 0);
            }
            public static int[] ReadInt32(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*4);
                ReverseBytes(memory);
                int[] numArray = new int[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToInt32(memory, ((length - 1) - i)*4);
                }
                return numArray;
            }
            public static long ReadInt64(uint address)
            {
                byte[] memory = GetMemoryInt(address, 8);
                Array.Reverse(memory, 0, 8);
                return BitConverter.ToInt64(memory, 0);
            }
            public static long[] ReadInt64(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*8);
                ReverseBytes(memory);
                long[] numArray = new long[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToInt64(memory, ((length - 1) - i)*8);
                }
                return numArray;
            }
            public static sbyte ReadSByte(uint address)
            {
                return (sbyte) GetMemoryInt(address, 1)[0];
            }
            public static sbyte[] ReadSBytes(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length);
                sbyte[] numArray = new sbyte[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = (sbyte) memory[i];
                }
                return numArray;
            }
            public static float ReadSingle(uint address)
            {
                byte[] memory = GetMemoryInt(address, 4);
                Array.Reverse(memory, 0, 4);
                return BitConverter.ToSingle(memory, 0);
            }
            public static int ReadInt(uint address)
            {
                byte[] buff = GetMemoryInt(address, 4);
                Array.Reverse(buff);
                int val = BitConverter.ToInt32(buff, 0);
                return val;
            }
            public static int ReadShort(uint address)
            {
                byte[] buffer = GetMemoryInt(address, 2);
                return (short) ((buffer[0] << 8) + buffer[1]);
            }
            public static float[] ReadSingle(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*4);
                ReverseBytes(memory);
                float[] numArray = new float[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToSingle(memory, ((length - 1) - i)*4);
                }
                return numArray;
            }
            public static ushort ReadUInt16(uint address)
            {
                byte[] memory = GetMemoryInt(address, 2);
                Array.Reverse(memory, 0, 2);
                return BitConverter.ToUInt16(memory, 0);
            }
            public static ushort[] ReadUInt16(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*2);
                ReverseBytes(memory);
                ushort[] numArray = new ushort[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToUInt16(memory, ((length - 1) - i)*2);
                }
                return numArray;
            }
            public static uint ReadUInt32(uint address)
            {
                byte[] memory = GetMemoryInt(address, 4);
                Array.Reverse(memory, 0, 4);
                return BitConverter.ToUInt32(memory, 0);
            }
            public static uint[] ReadUInt32(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*4);
                ReverseBytes(memory);
                uint[] numArray = new uint[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToUInt32(memory, ((length - 1) - i)*4);
                }
                return numArray;
            }
            public static ulong ReadUInt64(uint address)
            {
                byte[] memory = GetMemoryInt(address, 8);
                Array.Reverse(memory, 0, 8);
                return BitConverter.ToUInt64(memory, 0);
            }
            public static ulong[] ReadUInt64(uint address, int length)
            {
                byte[] memory = GetMemoryInt(address, length*8);
                ReverseBytes(memory);
                ulong[] numArray = new ulong[length];
                for (int i = 0; i < length; i++)
                {
                    numArray[i] = BitConverter.ToUInt64(memory, ((length - 1) - i)*8);
                }
                return numArray;
            }
            public static byte[] ReverseBytes(byte[] buff)
            {
                Array.Reverse(buff);
                return buff;
            }
            public static void WriteInt(uint address, int val)
            {
                SetMemory(address, ReverseBytes(BitConverter.GetBytes(val)), 0);
            }
            public static void WriteShort(uint address, int val, bool dvar = false)
            {
                byte[] data = BitConverter.GetBytes(val);
                if (!dvar)
                    SetMemory(address, new byte[] { data[0], data[1] }, 0);
                else
                    SetMemory(address, new byte[] { data[1], data[0] }, 0);
            }
            public static void WriteUInt(uint address, uint val)
            {
                SetMemory(address, ReverseBytes(BitConverter.GetBytes(val)), 0);
            }
            public static void WriteBool(uint address, bool input)
            {
                byte[] bytes = {input ? ((byte) 1) : ((byte) 0)};
                SetMemory(address, bytes);
            }
            public static void WriteByte(uint address, byte input)
            {
                SetMemory(address, new[] {input});
            }
            public static void WriteBytes(uint address, byte[] input)
            {
                SetMemory(address, input);
            }
            public static bool WriteBytesToggle(uint Offset, byte[] On, byte[] Off)
            {
                bool flag = ReadByte(Offset) == On[0];
                WriteBytes(Offset, !flag ? On : Off);
                return flag;
            }
            public static void WriteDouble(uint address, double input)
            {
                byte[] array = new byte[8];
                BitConverter.GetBytes(input).CopyTo(array, 0);
                Array.Reverse(array, 0, 8);
                SetMemory(address, array);
            }
            public static void WriteDouble(uint address, double[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*8];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*8));
                }
                SetMemory(address, array);
            }
            public static void WriteInt16(uint address, short input)
            {
                byte[] array = new byte[2];
                ReverseBytes(BitConverter.GetBytes(input)).CopyTo(array, 0);
                SetMemory(address, array);
            }
            public static void WriteInt16(uint address, short[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*2];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*2));
                }
                SetMemory(address, array);
            }
            public static void WriteInt32(uint address, int input)
            {
                byte[] array = new byte[4];
                ReverseBytes(BitConverter.GetBytes(input)).CopyTo(array, 0);
                SetMemory(address, array);
            }
            public static void WriteInt32(uint address, int[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*4];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*4));
                }
                SetMemory(address, array);
            }
            public static void WriteInt64(uint address, long input)
            {
                byte[] array = new byte[8];
                ReverseBytes(BitConverter.GetBytes(input)).CopyTo(array, 0);
                SetMemory(address, array);
            }
            public static void WriteInt64(uint address, long[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*8];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*8));
                }
                SetMemory(address, array);
            }
            public static void WriteSByte(uint address, sbyte input)
            {
                byte[] bytes = {(byte) input};
                SetMemory(address, bytes);
            }
            public static void WriteSBytes(uint address, sbyte[] input)
            {
                int length = input.Length;
                byte[] bytes = new byte[length];
                for (int i = 0; i < length; i++)
                {
                    bytes[i] = (byte) input[i];
                }
                SetMemory(address, bytes);
            }
            public static void WriteSingle(uint address, float input)
            {
                byte[] array = new byte[4];
                BitConverter.GetBytes(input).CopyTo(array, 0);
                Array.Reverse(array, 0, 4);
                SetMemory(address, array);
            }
            public static void WriteSingle(uint address, float[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*4];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*4));
                }
                SetMemory(address, array);
            }
            public static void WriteString(uint address, string input)
            {
                byte[] bytes = Encoding.UTF8.GetBytes(input);
                Array.Resize<byte>(ref bytes, bytes.Length + 1);
                SetMemory(address, bytes);
            }
            public static void WriteUInt16(uint address, ushort input)
            {
                byte[] array = new byte[2];
                BitConverter.GetBytes(input).CopyTo(array, 0);
                Array.Reverse(array, 0, 2);
                SetMemory(address, array);
            }
            public static void WriteUInt16(uint address, ushort[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*2];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*2));
                }
                SetMemory(address, array);
            }
            public static void WriteUInt32(uint address, uint input)
            {
                byte[] array = new byte[4];
                BitConverter.GetBytes(input).CopyTo(array, 0);
                Array.Reverse(array, 0, 4);
                SetMemory(address, array);
            }
            public static void WriteUInt32(uint address, uint[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*4];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*4));
                }
                SetMemory(address, array);
            }
            public static void WriteUInt64(uint address, ulong input)
            {
                byte[] array = new byte[8];
                BitConverter.GetBytes(input).CopyTo(array, 0);
                Array.Reverse(array, 0, 8);
                SetMemory(address, array);
            }
            public static void WriteUInt64(uint address, ulong[] input)
            {
                int length = input.Length;
                byte[] array = new byte[length*8];
                for (int i = 0; i < length; i++)
                {
                    ReverseBytes(BitConverter.GetBytes(input[i])).CopyTo(array, (int) (i*8));
                }
                SetMemory(address, array);
            }
        }
    }
   #endregion
}